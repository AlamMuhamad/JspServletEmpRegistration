package kanoo;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet")
public class LoginServelt extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Get user inputs from the form
            String name = request.getParameter("name");
            String address = request.getParameter("address");
            String role = request.getParameter("role");
            String department = request.getParameter("department");
            String cell = request.getParameter("cell");
            String email = request.getParameter("email");
            String dob = request.getParameter("dob");
            String gender = request.getParameter("gender");
            String salary = request.getParameter("salary");

            // JDBC Connection details
            String jdbcUrl = "jdbc:mysql://localhost:3306/employee_db";
            String dbUsername = "root";
            String dbPassword = "root";

            try {
                // Load the JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the database connection
                try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword)) {
                    // Insert employee data into the database
                    String sql = "INSERT INTO employees1 (name, address, role, department, cell,email,dob,gender,salary) VALUES (?, ?, ?, ?, ?,?,?,?,?)";
                    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                        preparedStatement.setString(1, name);
                        preparedStatement.setString(2, address);
                        preparedStatement.setString(3, role);
                        preparedStatement.setString(4, department);
                        preparedStatement.setString(5, cell);
                        preparedStatement.setString(6, email);
                        preparedStatement.setString(7, dob);
                        preparedStatement.setString(8, gender);
                        preparedStatement.setString(9, salary);

                        int rowsInserted = preparedStatement.executeUpdate();

                        if (rowsInserted > 0) {
                        	 response.sendRedirect("successful.jsp");
                        } else {
                        	 response.sendRedirect("error.jsp");
                        }
                    }
                }
            } catch (Exception e) {
                out.println("<h2>Error: " + e.getMessage() + "</h2>");
            }
        }
    }
}
